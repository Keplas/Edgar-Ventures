from django.shortcuts import render


def home(request):
    news_items = [
        {
            'category': 'Technology',
            'cat_class': 'nt',
            'title': 'EGV Launches New Digital Training Portal for East African SMEs',
            'excerpt': 'A new platform supporting over 5,000 small businesses with digital skills training, e-commerce onboarding, and cloud service access launches this quarter.',
            'date': 'Jun 24, 2026',
        },
        {
            'category': 'Trade',
            'cat_class': 'ntr',
            'title': 'Edgar Global Ventures Secures New Cross-Border Trade Route Partnership',
            'excerpt': 'A strategic agreement with regional logistics partners expands EGV\'s trade facilitation network to cover seven additional East African border crossings.',
            'date': 'Jun 18, 2026',
        },
        {
            'category': 'Agriculture',
            'cat_class': 'na',
            'title': 'Q3 Agri Training Cohort Launches with Record 400-Farmer Enrollment',
            'excerpt': 'This season\'s training program begins with participants across Masaka, Soroti, and Gulu, focused on climate-resilient crop management techniques.',
            'date': 'Jun 14, 2026',
        },
    ]

    return render(request, 'core/home.html', {
        'news_items': news_items,
    })


def about(request):
    return render(request, 'core/about.html')


def contact(request):
    return render(request, 'core/contact.html')


def sectors(request):
    return render(request, 'core/sectors.html')
